import javafx.event.Event;
import javafx.event.EventHandler;

public class HandleOkMousePress implements EventHandler {
    @Override
    public void handle(Event event) {

    }
}
